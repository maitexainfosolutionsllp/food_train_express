class Notifications {
  final String id;
  final String title;
  final String text;
  final String date;
  final String image;

  Notifications({this.id, this.title, this.text, this.date, this.image});
}
