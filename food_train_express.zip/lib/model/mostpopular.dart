
import 'package:fooddelivery/model/dishes.dart';

var mostPopular = [
  Dishes(image: "assets/pr1.jpg", text: "Buffalo Wild Wings", id : "p1", star: 4),
  Dishes(image: "assets/pr2.jpg", text: "Burger King", id : "p2", star: 3),
  Dishes(image: "assets/pr3.jpg", text: "Carl’s Jr.", id : "p3", star: 5),
  Dishes(image: "assets/pr4.jpg", text: "Chick-Fil-A", id : "p4", star: 5),
  Dishes(image: "assets/pr5.jpg", text: "Chili’s", id : "p5", star: 5),
  Dishes(image: "assets/pr6.jpg", text: "Cracker Barrel", id : "p6", star: 4),
];

