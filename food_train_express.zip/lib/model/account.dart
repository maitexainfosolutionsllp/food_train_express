class Account{
  String userName = "Jessica Prescott";
  String email = "jessica@gmail.com";
  String phone = "1233 4343 3343";
  String userAvatar = "assets/user.jpg";
  String userAvatarInternet = "https://www.valeraletun.ru/codecanyon/fooddel2/user2.jpg";
  String gender = "female";
  String dateOfBirth = "10/09/1995";

  int notifyCount = 4;
  int inBasket = 10;
}
