import 'package:fooddelivery/model/dishes.dart';

var basket = [
  Dishes(image: "assets/pr2.jpg", text: "Burger King", id : "p2", star: 3, price: 12.32, currency: "\₹", count: 1),
  Dishes(image: "assets/pr4.jpg", text: "Chick-Fil-A", id : "p4", star: 5, price: 24.9, currency: "\₹", count: 1),
  Dishes(image: "assets/pr5.jpg", text: "Chili’s", id : "p5", star: 5, price: 21.98, currency: "\₹", count: 1),

];

