class Restourant {
  final String image;
  final String text;
  final String text2;
  final int stars;
  final int starsCount;
  final String id;

  Restourant({this.image, this.text, this.text2, this.stars, this.id, this.starsCount});
}
