import 'package:fooddelivery/model/restourant.dart';

var topRestourant = [
  Restourant(image: "assets/top1.jpg", text : "Raleshop", text2: "Calicut", stars: 5, id : "1", starsCount: 223),
  Restourant(image: "assets/top2.jpg", text : "Raleshop 2", text2: "Kannur", stars: 4, id : "2", starsCount: 992),
  Restourant(image: "assets/top3.jpg", text : "Raleshop 3", text2: "Calicut", stars: 4, id : "3", starsCount: 443),
  Restourant(image: "assets/top4.jpg", text : "Raleshop 4", text2: "Vadakara", stars: 4, id : "4", starsCount: 124),
  Restourant(image: "assets/top5.jpg", text : "Raleshop 5", text2: "Kannur", stars: 5, id : "5", starsCount: 654),
];
