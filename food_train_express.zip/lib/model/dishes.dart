class Dishes {
  final String image;
  final String text;
  final int star;
  final String id;
  final String restaurant;
  final double price;
  final String currency;
  int count;
  Dishes({this.image, this.text, this.star, this.id, this.restaurant, this.price, this.currency, this.count});
}

