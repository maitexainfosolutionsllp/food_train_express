import 'package:fooddelivery/model/dishes.dart';

var trending = [
  Dishes(image: "assets/b1.jpg", text: "Applebee's", restaurant: "Le Sancerre", price: 15.99, id : "t1", currency: "\₹"),
  Dishes(image: "assets/b2.jpg", text: "Arby's", restaurant: "Le Basilic", price: 23.99, id : "t2", currency: "\₹"),
  Dishes(image: "assets/b3.jpg", text: "Salmon tartare", restaurant: "Le Basilic", price: 18.99, id : "t3", currency: "\₹"),
  Dishes(image: "assets/b4.jpg", text: "California Pizza Kitchen", restaurant: "Can Alegria Paris", price: 28.99, id : "t4", currency: "\₹"),
  Dishes(image: "assets/b5.jpg", text: "Carraba’s Italian Grill", restaurant: "Can Alegria Paris", price: 13.99, id : "t5", currency: "\₹"),
];
