class Products {
  final String image;
  final String title;
  final String id;
  final double price;
  final String currency;
  final bool instock;
  final int stars;
  final int sale;
  int count;

  Products({this.image, this.title, this.id, this.price, this.currency, this.instock, this.stars, this.sale, this.count});
}

